package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.deptDAO;

@WebServlet("/update")
public class Update extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		request.getParameter("loc");
		System.out.println(request.getParameter("loc"));
		String loc = request.getParameter("loc");
		int deptno = Integer.parseInt(request.getParameter("deptno"));
		
		boolean update = deptDAO.getupdate(loc, deptno);
		
		if(update == true ) {
			System.out.println("ㅅㅈ");
			response.sendRedirect("update.jsp");
		}else {
			System.out.println("ㅅㅁ");
			response.sendRedirect("failview.jsp");
		}
	}

}
